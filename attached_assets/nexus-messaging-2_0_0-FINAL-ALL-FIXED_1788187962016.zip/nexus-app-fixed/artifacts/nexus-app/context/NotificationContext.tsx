import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  ReactNode,
  useCallback,
} from 'react';
import * as Notifications from 'expo-notifications';
import { Platform, Alert } from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './AuthContext';
import type { AppNotification } from '@/lib/types';

// Set default notification handler
try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
} catch (error) {
  console.warn('⚠️ Failed to set notification handler:', error);
}

// Register notification categories for Android
async function registerNotificationCategories() {
  if (Platform.OS !== 'android') return;

  const categories = [
    {
      id: 'MESSAGE',
      config: [
        {
          identifier: 'REPLY',
          buttonTitle: 'Yanıtla',
          textInput: {
            submitButtonTitle: 'Gönder',
            placeholder: 'Mesajınızı yazın...',
          },
          options: {
            isDestructive: false,
            isAuthenticationRequired: false,
            opensAppToForeground: false,
          },
        },
        {
          identifier: 'OPEN',
          buttonTitle: 'Aç',
          options: { opensAppToForeground: true },
        },
      ],
    },
    {
      id: 'VIDEO',
      config: [
        {
          identifier: 'LIKE_VIDEO',
          buttonTitle: 'Beğen',
          options: { opensAppToForeground: false },
        },
        {
          identifier: 'OPEN_VIDEO',
          buttonTitle: 'Videoyu Gör',
          options: { opensAppToForeground: true },
        },
      ],
    },
    {
      id: 'CALL',
      config: [
        {
          identifier: 'ACCEPT_CALL',
          buttonTitle: 'Yanıtla',
          options: { opensAppToForeground: true },
        },
        {
          identifier: 'REJECT_CALL',
          buttonTitle: 'Reddet',
          options: { isDestructive: true, opensAppToForeground: false },
        },
      ],
    },
  ];

  for (const category of categories) {
    try {
      await Notifications.setNotificationCategoryAsync(category.id, category.config as any);
    } catch (error) {
      console.warn(`⚠️ Failed to set ${category.id} category:`, error);
    }
  }
}

interface NotificationContextValue {
  expoPushToken: string | null;
  notifications: AppNotification[];
  unreadCount: number;
  notificationError: Error | null;
  markAllRead: () => void;
  addNotification: (n: AppNotification) => void;
  clearNotification: (id: string) => void;
  clearError: () => void;
}

const NotificationContext = createContext<NotificationContextValue | null>(null);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notificationError, setNotificationError] = useState<Error | null>(null);
  const notificationListener = useRef<Notifications.EventSubscription | null>(null);
  const responseListener = useRef<Notifications.EventSubscription | null>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const addNotification = useCallback((n: AppNotification) => {
    try {
      if (!n || !n.id || typeof n.id !== 'string') {
        throw new Error('Invalid notification object');
      }
      setNotifications((prev) => {
        if (prev.find((x) => x.id === n.id)) return prev;
        return [n, ...prev].slice(0, 100); // Keep only 100 recent
      });
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to add notification');
      console.error('⚠️ addNotification:', err.message);
      setNotificationError(err);
    }
  }, []);

  const markAllRead = useCallback(() => {
    try {
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch (error) {
      console.error('⚠️ markAllRead failed:', error);
    }
  }, []);

  const clearNotification = useCallback((id: string) => {
    try {
      if (!id || typeof id !== 'string') {
        throw new Error('Invalid notification ID');
      }
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    } catch (error) {
      console.error('⚠️ clearNotification failed:', error);
    }
  }, []);

  const clearError = useCallback(() => {
    setNotificationError(null);
  }, []);

  // Setup notification listeners
  useEffect(() => {
    if (!isAuthenticated) return;

    registerNotificationCategories();

    // Register for push notifications
    registerForPushNotificationsAsync()
      .then((token) => {
        if (token) setExpoPushToken(token);
      })
      .catch((error) => {
        console.error('⚠️ Push notification registration failed:', error);
      });

    // Foreground notification listener
    try {
      notificationListener.current = Notifications.addNotificationReceivedListener(
        (notification) => {
          try {
            const { title, body, data } = notification.request.content;
            addNotification({
              id: notification.request.identifier,
              type: (data?.type as AppNotification['type']) || 'message',
              title: title || '',
              body: body || '',
              data: (data as Record<string, any>) || {},
              read: false,
              createdAt: new Date().toISOString(),
            });
          } catch (error) {
            console.error('⚠️ Failed to process notification:', error);
          }
        }
      );
    } catch (error) {
      console.error('⚠️ Failed to add notification listener:', error);
    }

    // Notification response listener
    try {
      responseListener.current = Notifications.addNotificationResponseReceivedListener(
        async (response) => {
          try {
            const { notification, actionIdentifier, userText } = response;
            const data = (notification.request.content.data as Record<string, any>) || {};

            // Validate action and data
            if (!actionIdentifier || typeof actionIdentifier !== 'string') {
              throw new Error('Invalid action identifier');
            }

            // Handle REPLY action
            if (actionIdentifier === 'REPLY' && userText && data?.conversationId) {
              try {
                const messageText = userText.trim();
                if (!messageText) {
                  throw new Error('Empty message');
                }

                const { api } = await import('@/lib/api');
                await api.conversations.sendMessage(data.conversationId, {
                  content: messageText,
                  type: 'text',
                });

                console.log('✅ Message sent from notification');

                // Navigate to conversation
                router.push(`/conversation/${data.conversationId}` as any).catch((err) => {
                  console.error('⚠️ Navigation failed:', err);
                });
              } catch (error) {
                const err = error instanceof Error ? error.message : 'Unknown error';
                console.error('⚠️ Failed to send message from notification:', err);
                Alert.alert('Hata', 'Mesaj gönderilemedi. Lütfen uygulamayı açarak tekrar deneyin.');
              }
            }
            // Handle LIKE_VIDEO action
            else if (actionIdentifier === 'LIKE_VIDEO' && data?.videoId) {
              router.push('/(tabs)/feed' as any).catch((err) => {
                console.error('⚠️ Navigation to feed failed:', err);
              });
            }
            // Handle ACCEPT_CALL action
            else if (actionIdentifier === 'ACCEPT_CALL' && data?.callId) {
              router.push(`/conversation/${data.conversationId}` as any).catch((err) => {
                console.error('⚠️ Navigation to call failed:', err);
              });
            }
            // Handle REJECT_CALL action
            else if (actionIdentifier === 'REJECT_CALL' && data?.callId) {
              console.log('✅ Call rejected from notification:', data.callId);
            }
            // Handle default notification tap
            else if (actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER) {
              if (data?.conversationId && typeof data.conversationId === 'number') {
                router.push(`/conversation/${data.conversationId}` as any).catch((err) => {
                  console.error('⚠️ Navigation failed:', err);
                });
              } else if (data?.videoId && typeof data.videoId === 'number') {
                router.push('/(tabs)/feed' as any).catch((err) => {
                  console.error('⚠️ Navigation to feed failed:', err);
                });
              } else if (data?.callId && typeof data.callId === 'string') {
                router.push(`/conversation/${data.conversationId}` as any).catch((err) => {
                  console.error('⚠️ Navigation failed:', err);
                });
              }
            }
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Unknown error';
            console.error('⚠️ Error handling notification response:', errorMsg);
          }
        }
      );
    } catch (error) {
      console.error('⚠️ Failed to add response listener:', error);
    }

    return () => {
      try {
        if (notificationListener.current) {
          Notifications.removeNotificationSubscription(notificationListener.current);
          notificationListener.current = null;
        }
        if (responseListener.current) {
          Notifications.removeNotificationSubscription(responseListener.current);
          responseListener.current = null;
        }
      } catch (error) {
        console.error('⚠️ Failed to cleanup notification listeners:', error);
      }
    };
  }, [isAuthenticated, addNotification]);

  const value: NotificationContextValue = {
    expoPushToken,
    notifications,
    unreadCount,
    notificationError,
    markAllRead,
    addNotification,
    clearNotification,
    clearError,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications(): NotificationContextValue {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications() must be used within <NotificationProvider>');
  }
  return context;
}

// Register for push notifications
async function registerForPushNotificationsAsync(): Promise<string | null> {
  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.warn('⚠️ Notification permissions not granted');
      return null;
    }

    // Setup Android notification channels
    if (Platform.OS === 'android') {
      const channels = [
        {
          id: 'default',
          name: 'Genel',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#7C3AED',
          enableVibrate: true,
          enableLights: true,
          sound: 'default',
        },
        {
          id: 'messages',
          name: 'Mesajlar',
          description: 'Yeni mesaj bildirimleri',
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 150],
          lightColor: '#7C3AED',
          enableVibrate: true,
          sound: 'default',
          showBadge: true,
        },
        {
          id: 'videos',
          name: 'Videolar',
          description: 'Yeni video ve beğeni bildirimleri',
          importance: Notifications.AndroidImportance.DEFAULT,
          sound: 'default',
          showBadge: true,
        },
      ];

      for (const channel of channels) {
        try {
          await Notifications.setNotificationChannelAsync(channel.id, channel as any);
        } catch (error) {
          console.warn(`⚠️ Failed to set ${channel.id} channel:`, error);
        }
      }
    }

    // Get Expo push token
    try {
      const tokenData = await Notifications.getExpoPushTokenAsync();
      if (tokenData?.data && typeof tokenData.data === 'string') {
        return tokenData.data;
      }
    } catch (error) {
      console.warn('⚠️ Failed to get Expo push token:', error);
    }

    return null;
  } catch (error) {
    console.error('⚠️ Push notification registration failed:', error);
    return null;
  }
}

// Helper to schedule local notification
export async function scheduleLocalNotification(opts: {
  title: string;
  body: string;
  data?: Record<string, any>;
  categoryIdentifier?: string;
  channelId?: string;
}): Promise<void> {
  try {
    if (!opts.title || !opts.body) {
      throw new Error('Title and body are required');
    }

    await Notifications.scheduleNotificationAsync({
      content: {
        title: opts.title,
        body: opts.body,
        data: opts.data || {},
        categoryIdentifier: opts.categoryIdentifier,
        sound: 'default',
        ...(Platform.OS === 'android' ? { channelId: opts.channelId || 'default' } : {}),
      },
      trigger: null, // immediate
    });
  } catch (error) {
    console.error('⚠️ Failed to schedule notification:', error);
  }
}
