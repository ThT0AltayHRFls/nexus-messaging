import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  ReactNode,
  useEffect,
} from 'react';

export interface IncomingCall {
  callId: string;
  type: 'voice' | 'video';
  from: number;
  fromName: string;
  fromAvatar?: string | null;
  conversationId: number;
  timestamp: number;
}

interface CallContextValue {
  incomingCall: IncomingCall | null;
  activeCall: IncomingCall | null;
  isCallActive: boolean;
  callError: Error | null;
  setIncomingCall: (call: IncomingCall | null) => void;
  acceptCall: (call: IncomingCall) => void;
  rejectCall: (callId: string) => void;
  endCall: () => void;
  clearError: () => void;
}

const CallContext = createContext<CallContextValue | null>(null);

export function CallProvider({ children }: { children: ReactNode }) {
  const [incomingCall, setIncomingCall] = useState<IncomingCall | null>(null);
  const [activeCall, setActiveCall] = useState<IncomingCall | null>(null);
  const [callError, setCallError] = useState<Error | null>(null);

  // Validate incoming call data
  const validateCall = useCallback((call: IncomingCall | null): boolean => {
    if (!call) return true;
    return !!(
      call.callId &&
      typeof call.callId === 'string' &&
      call.from > 0 &&
      call.fromName &&
      typeof call.fromName === 'string' &&
      call.conversationId > 0 &&
      (call.type === 'voice' || call.type === 'video')
    );
  }, []);

  // Safe incoming call setter with validation
  const safeSetIncomingCall = useCallback((call: IncomingCall | null) => {
    try {
      if (call && !validateCall(call)) {
        throw new Error('Invalid incoming call data structure');
      }
      setIncomingCall(call);
      setCallError(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Unknown error setting incoming call');
      setCallError(err);
      console.error('⚠️ CallContext setIncomingCall:', err.message);
    }
  }, [validateCall]);

  const acceptCall = useCallback((call: IncomingCall) => {
    try {
      if (!call) throw new Error('Cannot accept null call');
      if (!validateCall(call)) {
        throw new Error('Cannot accept invalid call data');
      }
      setActiveCall(call);
      setIncomingCall(null);
      setCallError(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to accept call');
      setCallError(err);
      console.error('⚠️ CallContext acceptCall:', err.message);
    }
  }, [validateCall]);

  const rejectCall = useCallback((callId: string) => {
    try {
      if (!callId || typeof callId !== 'string') {
        throw new Error('Invalid call ID for rejection');
      }
      setIncomingCall(null);
      setCallError(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to reject call');
      setCallError(err);
      console.error('⚠️ CallContext rejectCall:', err.message);
    }
  }, []);

  const endCall = useCallback(() => {
    try {
      setActiveCall(null);
      setIncomingCall(null);
      setCallError(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to end call');
      setCallError(err);
      console.error('⚠️ CallContext endCall:', err.message);
    }
  }, []);

  const clearError = useCallback(() => {
    setCallError(null);
  }, []);

  // Auto-cleanup incoming call after timeout
  useEffect(() => {
    if (!incomingCall) return;

    const timeout = setTimeout(() => {
      console.warn('⏱️ Incoming call timeout - auto-rejecting after 90s');
      rejectCall(incomingCall.callId);
    }, 90000); // 90 seconds

    return () => {
      clearTimeout(timeout);
    };
  }, [incomingCall, rejectCall]);

  const value: CallContextValue = {
    incomingCall,
    activeCall,
    isCallActive: !!activeCall,
    callError,
    setIncomingCall: safeSetIncomingCall,
    acceptCall,
    rejectCall,
    endCall,
    clearError,
  };

  return (
    <CallContext.Provider value={value}>
      {children}
    </CallContext.Provider>
  );
}

export function useCall(): CallContextValue {
  const context = useContext(CallContext);
  if (!context) {
    throw new Error('useCall() must be used within <CallProvider>. Ensure CallProvider wraps your component tree.');
  }
  return context;
}
