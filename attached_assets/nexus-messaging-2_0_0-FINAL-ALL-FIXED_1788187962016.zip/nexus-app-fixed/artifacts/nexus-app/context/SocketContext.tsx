import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  ReactNode,
  useCallback,
} from 'react';
import { io, Socket } from 'socket.io-client';
import { getBaseUrl } from '@/lib/api';
import { useAuth } from './AuthContext';
import { scheduleLocalNotification } from './NotificationContext';
import type { AppNotification } from '@/lib/types';

interface SocketContextValue {
  socket: Socket | null;
  isConnected: boolean;
  socketError: Error | null;
  on: (event: string, cb: (...args: any[]) => void) => void;
  off: (event: string, cb: (...args: any[]) => void) => void;
  clearError: () => void;
}

const SocketContext = createContext<SocketContextValue | null>(null);

export function SocketProvider({ children }: { children: ReactNode }) {
  const { token, isAuthenticated, user } = useAuth();
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [socketError, setSocketError] = useState<Error | null>(null);
  const reconnectAttemptRef = useRef(0);
  const maxReconnectAttemptsRef = useRef(10);

  const on = useCallback((event: string, cb: (...args: any[]) => void) => {
    try {
      if (!socketRef.current) {
        throw new Error('Socket not initialized');
      }
      if (!event || typeof event !== 'string') {
        throw new Error('Invalid event name');
      }
      if (typeof cb !== 'function') {
        throw new Error('Callback must be a function');
      }
      socketRef.current.on(event, cb);
    } catch (error) {
      console.error('⚠️ Socket.on error:', error);
      setSocketError(error instanceof Error ? error : new Error('Failed to register listener'));
    }
  }, []);

  const off = useCallback((event: string, cb: (...args: any[]) => void) => {
    try {
      if (!socketRef.current) return;
      if (!event || typeof event !== 'string') return;
      if (typeof cb !== 'function') return;
      socketRef.current.off(event, cb);
    } catch (error) {
      console.error('⚠️ Socket.off error:', error);
    }
  }, []);

  const clearError = useCallback(() => {
    setSocketError(null);
  }, []);

  // Safe notification scheduler with validation
  const safeScheduleNotification = useCallback(
    async (opts: {
      title: string;
      body: string;
      data?: Record<string, any>;
      categoryIdentifier?: string;
      channelId?: string;
    }) => {
      try {
        if (!opts.title || !opts.body) {
          throw new Error('Title and body required for notification');
        }
        await scheduleLocalNotification(opts);
      } catch (error) {
        console.error('⚠️ Notification scheduling failed:', error);
      }
    },
    []
  );

  // Setup socket connection
  useEffect(() => {
    if (!isAuthenticated || !token) {
      if (socketRef.current) {
        try {
          socketRef.current.disconnect();
          socketRef.current = null;
          setIsConnected(false);
        } catch (error) {
          console.error('⚠️ Socket disconnect failed:', error);
        }
      }
      return;
    }

    try {
      const baseUrl = getBaseUrl();
      if (!baseUrl) {
        throw new Error('API base URL not available');
      }

      const socket = io(baseUrl, {
        path: '/api/socket.io',
        transports: ['polling', 'websocket'],
        auth: { token },
        reconnection: true,
        reconnectionAttempts: maxReconnectAttemptsRef.current,
        reconnectionDelay: 1000,
        timeout: 20000,
      });

      // Connection events
      socket.on('connect', () => {
        console.log('✅ Socket connected');
        setIsConnected(true);
        setSocketError(null);
        reconnectAttemptRef.current = 0;
      });

      socket.on('disconnect', () => {
        console.log('⚠️ Socket disconnected');
        setIsConnected(false);
      });

      socket.on('connect_error', (err: any) => {
        console.error('⚠️ Socket connection error:', err);
        setIsConnected(false);
        const error = err instanceof Error ? err : new Error('Socket connection error');
        setSocketError(error);
        reconnectAttemptRef.current++;
      });

      // ────── MESSAGE EVENTS ──────
      socket.on('new_message', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          if (data.senderId === user?.id) return; // Own message

          const { conversationId, senderName, senderId, content, type } = data;
          if (!conversationId || !senderName) return;

          const body = content ||
            (type === 'image' ? '📷 Fotoğraf' : type === 'video' ? '🎥 Video' : '📎 Dosya');

          safeScheduleNotification({
            title: senderName,
            body,
            data: {
              type: 'message',
              conversationId,
              senderId,
            },
            categoryIdentifier: 'MESSAGE',
            channelId: 'messages',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle new_message:', error);
        }
      });

      // ────── VIDEO EVENTS ──────
      socket.on('video_liked', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { videoId, likerName, videoTitle } = data;
          if (!videoId || !likerName) return;

          safeScheduleNotification({
            title: 'Video beğenildi',
            body: `${likerName} videonuzu beğendi${videoTitle ? `: ${videoTitle}` : ''}`,
            data: {
              type: 'video_like',
              videoId,
            },
            categoryIdentifier: 'VIDEO',
            channelId: 'videos',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle video_liked:', error);
        }
      });

      socket.on('comment_hearted', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { videoId, hearterName } = data;
          if (!videoId || !hearterName) return;

          safeScheduleNotification({
            title: 'Yorumunuz kalp aldı 💜',
            body: `${hearterName} yorumunuza kalp bıraktı`,
            data: {
              type: 'comment_heart',
              videoId,
            },
            channelId: 'videos',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle comment_hearted:', error);
        }
      });

      socket.on('many_hearts', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { videoId, count } = data;
          if (!videoId || !count || count < 1) return;

          safeScheduleNotification({
            title: `${count}+ kullanıcı yorumunuza kalp bıraktı!`,
            body: 'Yorumunuz çok beğenildi',
            data: {
              type: 'many_hearts',
              videoId,
            },
            channelId: 'videos',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle many_hearts:', error);
        }
      });

      socket.on('followed_user_video', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { userId, userName, videoId, videoTitle } = data;
          if (!userId || !userName || !videoId) return;

          safeScheduleNotification({
            title: `${userName} yeni bir video paylaştı`,
            body: videoTitle || 'Yeni video',
            data: {
              type: 'new_video',
              videoId,
              userId,
            },
            categoryIdentifier: 'VIDEO',
            channelId: 'videos',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle followed_user_video:', error);
        }
      });

      socket.on('comment_liked', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { videoId, likerName } = data;
          if (!videoId || !likerName) return;

          safeScheduleNotification({
            title: 'Yorumunuz beğenildi',
            body: `${likerName} yorumunuzu beğendi`,
            data: {
              type: 'comment_like',
              videoId,
            },
            channelId: 'videos',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle comment_liked:', error);
        }
      });

      // ────── FOLLOW EVENTS ──────
      socket.on('new_follower', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { followerId, followerName } = data;
          if (!followerId || !followerName) return;

          safeScheduleNotification({
            title: 'Yeni takipçi',
            body: `${followerName} sizi takip etmeye başladı`,
            data: {
              type: 'follow',
              userId: followerId,
            },
            channelId: 'default',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle new_follower:', error);
        }
      });

      // ────── CALL EVENTS ──────
      socket.on('call-invite', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          if (data.from === user?.id) return;

          const { callId, type, fromName, from, conversationId } = data;
          if (!callId || !type || !fromName || !conversationId) return;
          if (type !== 'voice' && type !== 'video') return;

          safeScheduleNotification({
            title: `${fromName} sizi ${type === 'voice' ? 'arayıyor' : 'görüntülü arama yapıyor'}...`,
            body: type === 'voice' ? '📞 Sesli arama' : '📹 Görüntülü arama',
            data: {
              type: 'call',
              callType: type,
              callId,
              conversationId,
              from,
            },
            categoryIdentifier: 'CALL',
            channelId: 'default',
          });
        } catch (error) {
          console.error('⚠️ Failed to handle call-invite:', error);
        }
      });

      socket.on('call-accepted', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { callId, conversationId } = data;
          if (!callId || !conversationId) return;

          safeScheduleNotification({
            title: 'Arama başlandı',
            body: 'Arama bağlantısı kuruldu',
            data: {
              type: 'call_accepted',
              callId,
              conversationId,
            },
          });
        } catch (error) {
          console.error('⚠️ Failed to handle call-accepted:', error);
        }
      });

      socket.on('call-rejected', (data: any) => {
        try {
          if (!data || typeof data !== 'object') return;
          const { callId, reason } = data;
          if (!callId) return;

          safeScheduleNotification({
            title: 'Arama reddedildi',
            body: reason || 'Çağrı alıcı tarafından reddedildi',
            data: {
              type: 'call_rejected',
              callId,
            },
          });
        } catch (error) {
          console.error('⚠️ Failed to handle call-rejected:', error);
        }
      });

      socketRef.current = socket;
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Socket initialization failed');
      console.error('⚠️ Socket setup failed:', err.message);
      setSocketError(err);
      setIsConnected(false);
    }

    return () => {
      try {
        if (socketRef.current) {
          socketRef.current.disconnect();
          socketRef.current = null;
          setIsConnected(false);
        }
      } catch (error) {
        console.error('⚠️ Socket cleanup failed:', error);
      }
    };
  }, [isAuthenticated, token, user?.id, safeScheduleNotification]);

  const value: SocketContextValue = {
    socket: socketRef.current,
    isConnected,
    socketError,
    on,
    off,
    clearError,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket(): SocketContextValue {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket() must be used within <SocketProvider>');
  }
  return context;
}
