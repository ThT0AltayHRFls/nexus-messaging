import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Text,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';
import { useSocket } from '@/context/SocketContext';
import { useCall } from '@/context/CallContext';
import { api } from '@/lib/api';
import Avatar from '@/components/Avatar';
import MessageBubble from '@/components/MessageBubble';
import type { Message, Conversation } from '@/lib/types';

export default function ConversationScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user: me } = useAuth();
  const { socket, isConnected } = useSocket();
  const { activeCall, endCall } = useCall();
  const { id } = useLocalSearchParams<{ id: string }>();

  // Validate conversation ID
  const conversationId = useMemo(() => {
    try {
      if (!id || typeof id !== 'string') {
        throw new Error('Invalid conversation ID');
      }
      const parsed = parseInt(id, 10);
      if (isNaN(parsed) || parsed < 1) {
        throw new Error('Invalid conversation ID value');
      }
      return parsed;
    } catch (error) {
      console.error('⚠️ Conversation ID parsing failed:', error);
      return 0;
    }
  }, [id]);

  // State management
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [typingLabel, setTypingLabel] = useState('');
  const [isTypingLocal, setIsTypingLocal] = useState(false);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [screenError, setScreenError] = useState<Error | null>(null);

  // Refs for cleanup
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const flatListRef = useRef<FlatList>(null);
  const scrollTimeoutRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const isMountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
    };
  }, []);

  // Initial data load
  useEffect(() => {
    if (conversationId < 1) {
      setIsLoading(false);
      return;
    }

    const loadInitialData = async () => {
      try {
        setIsLoading(true);
        setScreenError(null);

        const [conv, msgs] = await Promise.all([
          api.conversations.get(conversationId).catch((err) => {
            console.error('⚠️ Failed to get conversation:', err);
            throw new Error('Failed to load conversation details');
          }),
          api.conversations.messages(conversationId).catch((err) => {
            console.error('⚠️ Failed to get messages:', err);
            throw new Error('Failed to load messages');
          }),
        ]);

        if (isMountedRef.current) {
          setConversation(conv);
          setMessages(msgs || []);
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : 'Unknown error';
        console.error('⚠️ Initial data load failed:', errorMsg);
        setScreenError(error instanceof Error ? error : new Error(errorMsg));

        if (isMountedRef.current) {
          Alert.alert('Hata', 'Sohbet yüklenemedi. Lütfen tekrar deneyin.', [
            { text: 'Geri Dön', onPress: () => router.back() },
          ]);
        }
      } finally {
        if (isMountedRef.current) {
          setIsLoading(false);
        }
      }
    };

    loadInitialData();
  }, [conversationId]);

  // Socket room management
  useEffect(() => {
    if (!socket || !isConnected || conversationId < 1) return;

    try {
      socket.emit('join-conversation', conversationId);
    } catch (error) {
      console.error('⚠️ Failed to join conversation:', error);
    }

    return () => {
      try {
        socket.emit('leave-conversation', conversationId);
      } catch (error) {
        console.error('⚠️ Failed to leave conversation:', error);
      }
    };
  }, [socket, isConnected, conversationId]);

  // Socket event listeners
  useEffect(() => {
    if (!socket) return;

    const onNewMessage = (msg: any) => {
      try {
        if (!msg || typeof msg !== 'object') return;
        if (msg.conversationId !== conversationId) return;

        if (isMountedRef.current) {
          setMessages((prev) => [...prev, msg]);
          // Scroll to bottom with delay
          if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
          scrollTimeoutRef.current = setTimeout(() => {
            if (isMountedRef.current && flatListRef.current) {
              flatListRef.current.scrollToEnd({ animated: true });
            }
          }, 100);
        }
      } catch (error) {
        console.error('⚠️ Failed to handle new message:', error);
      }
    };

    const onUserTyping = (data: any) => {
      try {
        if (isMountedRef.current) {
          setTypingLabel('typing...');
          if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
          typingTimeoutRef.current = setTimeout(
            () => {
              if (isMountedRef.current) setTypingLabel('');
            },
            3000
          );
        }
      } catch (error) {
        console.error('⚠️ Failed to handle typing:', error);
      }
    };

    const onMessageEdited = (updated: any) => {
      try {
        if (!updated || !updated.id) return;
        if (isMountedRef.current) {
          setMessages((prev) =>
            prev.map((m) => (m.id === updated.id ? { ...m, ...updated } : m))
          );
        }
      } catch (error) {
        console.error('⚠️ Failed to handle message edit:', error);
      }
    };

    const onMessageDeleted = (data: any) => {
      try {
        if (!data || !data.messageId) return;
        if (isMountedRef.current) {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === data.messageId ? { ...m, isDeleted: true, content: null } : m
            )
          );
        }
      } catch (error) {
        console.error('⚠️ Failed to handle message deletion:', error);
      }
    };

    socket.on('new-message', onNewMessage);
    socket.on('user-typing', onUserTyping);
    socket.on('message-edited', onMessageEdited);
    socket.on('message-deleted', onMessageDeleted);

    return () => {
      socket.off('new-message', onNewMessage);
      socket.off('user-typing', onUserTyping);
      socket.off('message-edited', onMessageEdited);
      socket.off('message-deleted', onMessageDeleted);
    };
  }, [socket, conversationId]);

  // Text input handler
  const handleTextChange = useCallback(
    (text: string) => {
      try {
        setInputText(text);

        if (!isTypingLocal && socket) {
          setIsTypingLocal(true);
          socket.emit('typing', { conversationId });
        }

        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => {
          if (socket) {
            socket.emit('stop-typing', { conversationId });
          }
          setIsTypingLocal(false);
        }, 1500);
      } catch (error) {
        console.error('⚠️ Failed to handle text change:', error);
      }
    },
    [conversationId, isTypingLocal, socket]
  );

  // Send message handler
  const handleSend = useCallback(async () => {
    try {
      const content = inputText.trim();
      if (!content || isSending || conversationId < 1) return;

      setInputText('');
      const replyId = replyTo?.id;
      setReplyTo(null);
      setIsSending(true);

      await api.conversations.sendMessage(conversationId, {
        content,
        type: 'text',
        replyToId: replyId,
      });

      if (isMountedRef.current) {
        // Success - message will be received via socket
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Send message failed:', errorMsg);

      if (isMountedRef.current) {
        setInputText(inputText);
        Alert.alert('Hata', 'Mesaj gönderilemedi. Lütfen tekrar deneyin.');
      }
    } finally {
      if (isMountedRef.current) {
        setIsSending(false);
      }
    }
  }, [inputText, isSending, conversationId, replyTo]);

  // Image picker handler
  const handlePickImage = useCallback(async () => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });

      if (result.canceled || !result.assets?.[0]) return;

      const asset = result.assets[0];
      if (!asset.uri || conversationId < 1) {
        throw new Error('Invalid image or conversation');
      }

      setIsSending(true);

      try {
        const uploaded = await api.upload.file(
          asset.uri,
          'image/jpeg',
          `photo-${Date.now()}.jpg`
        );

        if (!uploaded?.url) {
          throw new Error('Upload failed - no URL returned');
        }

        await api.conversations.sendMessage(conversationId, {
          type: 'image',
          mediaUrl: uploaded.url,
          mediaSize: uploaded.size,
          mediaName: uploaded.name,
        });
      } catch (uploadError) {
        console.error('⚠️ Image upload failed:', uploadError);
        Alert.alert('Hata', 'Görüntü gönderilemedi. Lütfen tekrar deneyin.');
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Image picker failed:', errorMsg);
      Alert.alert('Hata', 'Görüntü seçilemedi. Lütfen tekrar deneyin.');
    } finally {
      if (isMountedRef.current) {
        setIsSending(false);
      }
    }
  }, [conversationId]);

  // Call handlers
  const initiateCall = useCallback(
    (type: 'voice' | 'video') => {
      try {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

        if (conversation?.type !== 'direct' || !conversation.otherUser) {
          Alert.alert('Hata', 'Aramalar sadece kişisel sohbetlerde yapılabilir');
          return;
        }

        if (!socket) {
          Alert.alert('Hata', 'Sunucuya bağlı değilsiniz');
          return;
        }

        if (!me) {
          Alert.alert('Hata', 'Kullanıcı bilgileri yüklenemedi');
          return;
        }

        const callId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        socket.emit('call-invite', {
          callId,
          type,
          from: me.id,
          fromName: me.displayName,
          to: conversation.otherUser.id,
          conversationId,
        });

        Alert.alert(
          `${type === 'voice' ? 'Sesli' : 'Görüntülü'} Arama`,
          `${conversation.otherUser.displayName} aranıyor...`,
          [
            {
              text: 'İptal Et',
              style: 'cancel',
              onPress: () => {
                try {
                  socket.emit('call-cancel', { callId, conversationId });
                } catch (error) {
                  console.error('⚠️ Failed to cancel call:', error);
                }
              },
            },
          ]
        );
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : 'Unknown error';
        console.error('⚠️ Call initiation failed:', errorMsg);
        Alert.alert('Hata', 'Arama başlatılamadı. Lütfen tekrar deneyin.');
      }
    },
    [conversation, socket, me, conversationId]
  );

  // Message long press handler
  const handleMsgLongPress = useCallback(
    (item: Message) => {
      try {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});

        const isMine = item.senderId === me?.id;
        const options = [
          { text: 'Yanıtla', onPress: () => setReplyTo(item) },
          ...(isMine && !item.isDeleted
            ? [
                {
                  text: 'Sil',
                  style: 'destructive' as const,
                  onPress: async () => {
                    try {
                      await api.conversations.deleteMessage(conversationId, item.id);
                    } catch (error) {
                      console.error('⚠️ Delete failed:', error);
                      Alert.alert('Hata', 'Mesaj silinemedi');
                    }
                  },
                },
                {
                  text: 'Herkes İçin Sil',
                  style: 'destructive' as const,
                  onPress: async () => {
                    try {
                      await api.conversations.deleteMessage(conversationId, item.id);
                      socket?.emit('message-deleted-everywhere', {
                        messageId: item.id,
                        conversationId,
                      });
                    } catch (error) {
                      console.error('⚠️ Delete everywhere failed:', error);
                      Alert.alert('Hata', 'Mesaj silinemedi');
                    }
                  },
                },
              ]
            : []),
          { text: 'İptal', style: 'cancel' as const },
        ];

        Alert.alert('Mesaj', undefined, options);
      } catch (error) {
        console.error('⚠️ Long press handler failed:', error);
      }
    },
    [me?.id, conversationId, socket]
  );

  // Computed values
  const title = useMemo(
    () =>
      conversation?.type === 'direct'
        ? conversation.otherUser?.displayName ?? 'Kullanıcı'
        : conversation?.name ?? 'Grup',
    [conversation]
  );

  const subtitle = useMemo(
    () =>
      typingLabel ||
      (conversation?.type === 'direct'
        ? conversation.otherUser?.isOnline
          ? 'online'
          : 'kısa süre önce aktifti'
        : `${conversation?.membersCount ?? 0} üye`),
    [conversation, typingLabel]
  );

  const isOnline = useMemo(
    () => conversation?.type === 'direct' && !!conversation.otherUser?.isOnline,
    [conversation]
  );

  // Safety check
  if (conversationId < 1 && !isLoading) {
    return (
      <View style={[styles.center, { backgroundColor: colors?.background || '#1F2937' }]}>
        <Text style={{ color: colors?.foreground || '#FFF' }}>Geçersiz sohbet kimliği</Text>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View style={[styles.center, { backgroundColor: colors?.background || '#1F2937' }]}>
        <ActivityIndicator color={colors?.primary || '#7C3AED'} size="large" />
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors?.background || '#1F2937' }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + 6,
            backgroundColor: colors?.card || '#111827',
            borderBottomColor: colors?.border || '#374151',
          },
        ]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={28} color={colors?.foreground || '#FFF'} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.headerMid}
          activeOpacity={0.75}
          onPress={() => {
            try {
              if (conversation?.type === 'direct' && conversation.otherUser) {
                router.push(`/user/${conversation.otherUser.id}` as any);
              }
            } catch (error) {
              console.error('⚠️ Navigation to user profile failed:', error);
            }
          }}
        >
          <Avatar
            uri={
              conversation?.type === 'direct'
                ? conversation.otherUser?.avatarUrl
                : conversation?.avatarUrl
            }
            name={title}
            size={36}
            isOnline={isOnline}
            borderColor={colors?.card || '#111827'}
          />
          <View style={styles.headerText}>
            <Text
              style={[styles.headerName, { color: colors?.foreground || '#FFF' }]}
              numberOfLines={1}
            >
              {title}
            </Text>
            <Text
              style={[
                styles.headerSub,
                {
                  color:
                    isOnline || typingLabel
                      ? colors?.primary || '#10B981'
                      : colors?.mutedForeground || '#9CA3AF',
                },
              ]}
              numberOfLines={1}
            >
              {subtitle}
            </Text>
          </View>
        </TouchableOpacity>

        <View style={styles.headerRight}>
          <TouchableOpacity onPress={() => initiateCall('voice')} style={styles.iconBtn}>
            <Ionicons
              name="call-outline"
              size={22}
              color={colors?.mutedForeground || '#9CA3AF'}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => initiateCall('video')} style={styles.iconBtn}>
            <Ionicons
              name="videocam-outline"
              size={22}
              color={colors?.mutedForeground || '#9CA3AF'}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Active Call Banner */}
      {activeCall && (
        <View
          style={[
            styles.activeCallBanner,
            { backgroundColor: colors?.primary || '#7C3AED', paddingTop: 8 },
          ]}
        >
          <View style={styles.activeCallContent}>
            <Ionicons
              name={activeCall.type === 'voice' ? 'call' : 'videocam'}
              size={16}
              color="#FFF"
            />
            <Text style={styles.activeCallText}>
              {activeCall.type === 'voice'
                ? 'Sesli arama devam ediyor'
                : 'Görüntülü arama devam ediyor'}
            </Text>
          </View>
          <TouchableOpacity onPress={endCall}>
            <Ionicons name="close" size={18} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}

      {/* Messages List */}
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item, index }) => (
          <MessageBubble
            message={item}
            isMine={item.senderId === me?.id}
            showAvatar={
              conversation?.type !== 'direct' &&
              (index === 0 || messages[index - 1]?.senderId !== item.senderId)
            }
            onLongPress={() => handleMsgLongPress(item)}
          />
        )}
        contentContainerStyle={styles.msgList}
        onContentSizeChange={() => {
          if (flatListRef.current) {
            flatListRef.current.scrollToEnd({ animated: false });
          }
        }}
        showsVerticalScrollIndicator={false}
        scrollEnabled={true}
        nestedScrollEnabled={true}
      />

      {/* Reply Banner */}
      {replyTo && (
        <View
          style={[
            styles.replyBar,
            {
              backgroundColor: colors?.secondary || '#1E3A8A',
              borderLeftColor: colors?.primary || '#7C3AED',
            },
          ]}
        >
          <View style={styles.replyBarContent}>
            <Text style={[styles.replyBarName, { color: colors?.primary || '#7C3AED' }]}>
              {replyTo.senderName}
            </Text>
            <Text
              style={[styles.replyBarText, { color: colors?.mutedForeground || '#9CA3AF' }]}
              numberOfLines={1}
            >
              {replyTo.isDeleted ? 'Silinmiş mesaj' : replyTo.content || `[${replyTo.type}]`}
            </Text>
          </View>
          <TouchableOpacity onPress={() => setReplyTo(null)} style={styles.replyBarClose}>
            <Ionicons name="close" size={18} color={colors?.mutedForeground || '#9CA3AF'} />
          </TouchableOpacity>
        </View>
      )}

      {/* Input Bar */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View
          style={[
            styles.inputBar,
            {
              backgroundColor: colors?.card || '#111827',
              borderTopColor: colors?.border || '#374151',
              paddingBottom: insets.bottom + 6,
            },
          ]}
        >
          <TouchableOpacity onPress={handlePickImage} style={styles.inputBtn}>
            <Ionicons
              name="image-outline"
              size={24}
              color={colors?.mutedForeground || '#9CA3AF'}
            />
          </TouchableOpacity>

          <View
            style={[
              styles.inputBox,
              {
                backgroundColor: colors?.input || '#374151',
                borderRadius: 22,
              },
            ]}
          >
            <TextInput
              style={[styles.input, { color: colors?.foreground || '#FFF' }]}
              placeholder="Mesajınızı yazın..."
              placeholderTextColor={colors?.mutedForeground || '#9CA3AF'}
              value={inputText}
              onChangeText={handleTextChange}
              multiline
              maxLength={4000}
              editable={!isSending}
            />
          </View>

          {inputText.trim() ? (
            <TouchableOpacity
              onPress={handleSend}
              disabled={isSending}
              style={[
                styles.sendBtn,
                {
                  backgroundColor: colors?.primary || '#7C3AED',
                  borderRadius: 22,
                  opacity: isSending ? 0.6 : 1,
                },
              ]}
            >
              <Ionicons name="send" size={18} color="#FFF" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={styles.inputBtn}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
                Alert.alert(
                  'Ses Mesajı',
                  'Ses mesajı özelliği yakında eklenecek. Şimdilik yazılı mesaj gönderin.',
                  [{ text: 'Tamam' }]
                );
              }}
            >
              <Ionicons
                name="mic-outline"
                size={24}
                color={colors?.mutedForeground || '#9CA3AF'}
              />
            </TouchableOpacity>
          )}
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  activeCallBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingBottom: 8,
    gap: 8,
  },
  activeCallContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  activeCallText: {
    color: '#FFF',
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingBottom: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { padding: 6 },
  headerMid: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, marginLeft: 4 },
  headerText: { flex: 1 },
  headerName: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
  headerSub: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  headerRight: { flexDirection: 'row' },
  iconBtn: { padding: 8 },
  msgList: { paddingVertical: 8, paddingHorizontal: 4 },
  replyBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
    marginBottom: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderLeftWidth: 3,
    borderRadius: 8,
    gap: 8,
  },
  replyBarContent: { flex: 1 },
  replyBarName: { fontSize: 12, fontFamily: 'Inter_600SemiBold', marginBottom: 2 },
  replyBarText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  replyBarClose: { padding: 4 },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 8,
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    gap: 6,
  },
  inputBtn: { padding: 6, paddingBottom: 8 },
  inputBox: {
    flex: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
    maxHeight: 120,
    minHeight: 42,
    justifyContent: 'center',
  },
  input: { fontSize: 15, fontFamily: 'Inter_400Regular', lineHeight: 20 },
  sendBtn: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 0,
  },
});
