import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const isMountedRef = useRef(true);

  React.useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const handleLogin = useCallback(async () => {
    try {
      // Validation
      const usernameVal = String(username || '').trim();
      const passwordVal = String(password || '').trim();

      if (!usernameVal) {
        Alert.alert('Hata', 'Kullanıcı adını girin');
        return;
      }

      if (!passwordVal) {
        Alert.alert('Hata', 'Şifreyi girin');
        return;
      }

      if (!isMountedRef.current) return;
      setIsLoading(true);

      // Login attempt
      await login(usernameVal, passwordVal);

      if (!isMountedRef.current) return;

      try {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (e) {
        console.warn('Haptic failed:', e);
      }

      // Safe navigation
      try {
        router.replace('/(tabs)' as any);
      } catch (navError) {
        console.error('Navigation failed:', navError);
        if (isMountedRef.current) {
          Alert.alert('Hata', 'Sayfaya gidilemedi. Lütfen tekrar deneyiniz.');
        }
      }
    } catch (err: any) {
      if (!isMountedRef.current) return;

      try {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } catch (e) {
        console.warn('Haptic failed:', e);
      }

      const errorMsg = err?.message || 'Giriş başarısız oldu';
      Alert.alert('Giriş Hatası', errorMsg);
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [username, password, login]);

  const handleRegisterPress = useCallback(() => {
    try {
      router.push('/(auth)/register' as any);
    } catch (error) {
      console.error('Navigation error:', error);
    }
  }, []);

  const bgColor = colors?.background || '#0B0B14';
  const secondary = colors?.secondary || '#1a1a2e';
  const foreground = colors?.foreground || '#FFFFFF';
  const muted = colors?.mutedForeground || '#999999';
  const primary = colors?.primary || '#7C3AED';
  const accent = colors?.accent || '#EC4899';

  return (
    <LinearGradient
      colors={[bgColor, secondary, bgColor]}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={[
            styles.container,
            {
              paddingTop: (insets?.top || 0) + 60,
              paddingBottom: (insets?.bottom || 0) + 40,
            },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Logo */}
          <View style={styles.logoContainer}>
            <LinearGradient
              colors={[primary, accent]}
              style={[styles.logoCircle, { borderRadius: 24 }]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <Ionicons name="diamond" size={44} color="#FFF" />
            </LinearGradient>
            <Text style={[styles.logoText, { color: foreground }]}>Nexus</Text>
            <Text style={[styles.tagline, { color: muted }]}>
              Kişisel mesajlaşma uygulaması
            </Text>
          </View>

          {/* Form */}
          <View style={styles.formContainer}>
            {/* Username Input */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>Kullanıcı Adı</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="person" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="Kullanıcı adınız"
                  placeholderTextColor={muted}
                  value={username}
                  onChangeText={(text) => setUsername(String(text || ''))}
                  editable={!isLoading}
                  maxLength={50}
                />
              </View>
            </View>

            {/* Password Input */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>Şifre</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="lock-closed" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="Şifreniz"
                  placeholderTextColor={muted}
                  value={password}
                  onChangeText={(text) => setPassword(String(text || ''))}
                  secureTextEntry={!showPassword}
                  editable={!isLoading}
                  maxLength={100}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  <Ionicons
                    name={showPassword ? 'eye' : 'eye-off'}
                    size={18}
                    color={primary}
                  />
                </TouchableOpacity>
              </View>
            </View>

            {/* Login Button */}
            <TouchableOpacity
              style={[styles.button, { backgroundColor: primary }]}
              onPress={handleLogin}
              disabled={isLoading}
              activeOpacity={0.8}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFF" />
              ) : (
                <Text style={styles.buttonText}>Giriş Yap</Text>
              )}
            </TouchableOpacity>

            {/* Register Link */}
            <View style={styles.registerContainer}>
              <Text style={[styles.registerText, { color: muted }]}>
                Hesabın yok mu?{' '}
              </Text>
              <TouchableOpacity
                onPress={handleRegisterPress}
                disabled={isLoading}
              >
                <Text style={[styles.registerLink, { color: primary }]}>
                  Kaydol
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  container: {
    paddingHorizontal: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tagline: {
    fontSize: 14,
    fontWeight: '500',
  },
  formContainer: {
    gap: 20,
  },
  inputWrapper: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 50,
    gap: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  button: {
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  registerText: {
    fontSize: 14,
  },
  registerLink: {
    fontSize: 14,
    fontWeight: '600',
  },
});
