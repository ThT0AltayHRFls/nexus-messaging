import React, { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Alert,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import Avatar from './Avatar';

interface IncomingCallScreenProps {
  callerId: number;
  callerName: string;
  callerAvatar?: string | null;
  callType: 'voice' | 'video';
  callId: string;
  onAccept: () => void | Promise<void>;
  onReject: () => void | Promise<void>;
  isVisible: boolean;
}

export default function IncomingCallScreen({
  callerId,
  callerName,
  callerAvatar,
  callType,
  callId,
  onAccept,
  onReject,
  isVisible,
}: IncomingCallScreenProps) {
  const colors = useColors();
  const [duration, setDuration] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const pulseAnimRef = useRef(new Animated.Value(1));
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const animationRef = useRef<Animated.CompositeAnimation | null>(null);

  // Validate props
  const validCall = useMemo(
    () =>
      callerId > 0 &&
      callerName &&
      typeof callerName === 'string' &&
      callId &&
      typeof callId === 'string' &&
      (callType === 'voice' || callType === 'video'),
    [callerId, callerName, callId, callType]
  );

  // Pulse animation setup with proper cleanup
  useEffect(() => {
    if (!isVisible || !validCall) return;

    try {
      const animation = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnimRef.current, {
            toValue: 1.1,
            duration: 600,
            useNativeDriver: false,
          }),
          Animated.timing(pulseAnimRef.current, {
            toValue: 1,
            duration: 600,
            useNativeDriver: false,
          }),
        ])
      );

      animationRef.current = animation;
      animation.start();

      return () => {
        if (animationRef.current) {
          animationRef.current.stop();
          animationRef.current = null;
        }
        pulseAnimRef.current.setValue(1);
      };
    } catch (error) {
      console.error('⚠️ Failed to start pulse animation:', error);
    }
  }, [isVisible, validCall]);

  // Call duration timer with proper cleanup
  useEffect(() => {
    if (!isVisible || !validCall) {
      setDuration(0);
      return;
    }

    try {
      intervalRef.current = setInterval(() => {
        setDuration((prev) => {
          // Auto-reject after 120 seconds
          if (prev >= 120) {
            console.warn('⏱️ Call duration limit reached - auto-rejecting');
            handleRejectSafe();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);

      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      };
    } catch (error) {
      console.error('⚠️ Failed to setup call timer:', error);
    }
  }, [isVisible, validCall]);

  // Safe haptic feedback
  const triggerHaptic = useCallback(
    (style: Haptics.ImpactFeedbackStyle) => {
      try {
        Haptics.impactAsync(style).catch((err) => {
          console.warn('⚠️ Haptics failed:', err);
        });
      } catch (error) {
        console.warn('⚠️ Haptic feedback not available');
      }
    },
    []
  );

  // Safe accept handler with debounce
  const handleAcceptSafe = useCallback(async () => {
    if (!validCall || isProcessing) return;

    try {
      setIsProcessing(true);
      triggerHaptic(Haptics.ImpactFeedbackStyle.Heavy);

      if (typeof onAccept === 'function') {
        await Promise.resolve(onAccept());
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Failed to accept call:', errorMsg);
      Alert.alert('Hata', 'Arama kabul edilemedi. Lütfen tekrar deneyin.');
    } finally {
      setIsProcessing(false);
    }
  }, [validCall, isProcessing, onAccept, triggerHaptic]);

  // Safe reject handler with debounce
  const handleRejectSafe = useCallback(async () => {
    if (!validCall || isProcessing) return;

    try {
      setIsProcessing(true);
      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);

      if (typeof onReject === 'function') {
        await Promise.resolve(onReject());
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Failed to reject call:', errorMsg);
      Alert.alert('Hata', 'Arama reddedilemedi. Lütfen tekrar deneyin.');
    } finally {
      setIsProcessing(false);
    }
  }, [validCall, isProcessing, onReject, triggerHaptic]);

  // Format duration safely
  const formatDuration = useCallback((seconds: number): string => {
    try {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } catch (error) {
      console.error('⚠️ Duration format error:', error);
      return '00:00';
    }
  }, []);

  // Validate colors
  const safeColors = useMemo(
    () => ({
      background: colors?.background || '#1F2937',
      card: colors?.card || '#111827',
      foreground: colors?.foreground || '#FFFFFF',
      mutedForeground: colors?.mutedForeground || '#9CA3AF',
      primary: colors?.primary || '#7C3AED',
      destructive: colors?.destructive || '#EF4444',
    }),
    [colors]
  );

  if (!isVisible || !validCall) return null;

  return (
    <View style={[styles.container, { backgroundColor: safeColors.background }]}>
      {/* Background overlay */}
      <View style={[styles.gradient, { backgroundColor: safeColors.card }]} />

      {/* Content */}
      <View style={styles.content}>
        {/* Caller Avatar with pulse */}
        {callerAvatar || callerName ? (
          <Animated.View
            style={[
              styles.avatarContainer,
              { transform: [{ scale: pulseAnimRef.current }] },
            ]}
          >
            <Avatar
              uri={callerAvatar}
              name={callerName}
              size={120}
              borderColor={safeColors.primary}
            />
          </Animated.View>
        ) : null}

        {/* Caller Name */}
        {callerName ? (
          <Text
            style={[styles.callerName, { color: safeColors.foreground }]}
            numberOfLines={2}
          >
            {callerName}
          </Text>
        ) : null}

        {/* Call Type Label */}
        <Text
          style={[styles.callTypeLabel, { color: safeColors.mutedForeground }]}
        >
          {callType === 'voice' ? '📞 Sesli Arama' : '📹 Görüntülü Arama'}
        </Text>

        {/* Duration Timer */}
        <Text
          style={[styles.duration, { color: safeColors.mutedForeground }]}
        >
          {formatDuration(duration)}
        </Text>
      </View>

      {/* Call Actions */}
      <View style={[styles.actions, { paddingBottom: Math.max(32, 16) }]}>
        {/* Reject Button */}
        <TouchableOpacity
          onPress={handleRejectSafe}
          disabled={isProcessing || !validCall}
          style={[
            styles.button,
            styles.rejectBtn,
            {
              backgroundColor: safeColors.destructive,
              opacity: isProcessing ? 0.6 : 1,
            },
          ]}
          activeOpacity={0.7}
        >
          <Ionicons name="close" size={32} color="#FFFFFF" />
        </TouchableOpacity>

        {/* Accept Button */}
        <TouchableOpacity
          onPress={handleAcceptSafe}
          disabled={isProcessing || !validCall}
          style={[
            styles.button,
            styles.acceptBtn,
            {
              backgroundColor: safeColors.primary,
              opacity: isProcessing ? 0.6 : 1,
            },
          ]}
          activeOpacity={0.7}
        >
          <Ionicons
            name={callType === 'voice' ? 'call' : 'videocam'}
            size={32}
            color="#FFFFFF"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  gradient: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.5,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  avatarContainer: {
    marginBottom: 32,
  },
  callerName: {
    fontSize: 28,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 8,
    textAlign: 'center',
    marginHorizontal: 16,
  },
  callTypeLabel: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    marginBottom: 16,
    textAlign: 'center',
  },
  duration: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'center',
  },
  actions: {
    flexDirection: 'row',
    gap: 24,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  button: {
    width: 68,
    height: 68,
    borderRadius: 34,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  rejectBtn: {},
  acceptBtn: {},
});
