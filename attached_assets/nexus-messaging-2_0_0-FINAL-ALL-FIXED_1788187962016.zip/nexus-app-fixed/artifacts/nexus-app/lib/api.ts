import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const TOKEN_KEY = '@nexus/token';
const REQUEST_TIMEOUT = 30000; // 30 seconds
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

export function getBaseUrl(): string {
  const configuredApiUrl = process.env.EXPO_PUBLIC_API_URL?.trim();
  if (configuredApiUrl && typeof configuredApiUrl === 'string') {
    return configuredApiUrl.replace(/\/+$/, '');
  }

  const domain = process.env.EXPO_PUBLIC_DOMAIN;
  if (domain && typeof domain === 'string') {
    const normalizedDomain = domain.trim().replace(/\/+$/, '');
    return /^https?:\/\//i.test(normalizedDomain)
      ? normalizedDomain
      : `https://${normalizedDomain}`;
  }

  // Fallback for development
  return 'https://nexus-api.vercel.app';
}

export async function getToken(): Promise<string | null> {
  try {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    return token && typeof token === 'string' ? token : null;
  } catch (error) {
    console.error('⚠️ Failed to get token:', error);
    return null;
  }
}

export async function setToken(token: string): Promise<void> {
  try {
    if (!token || typeof token !== 'string') {
      throw new Error('Invalid token');
    }
    await AsyncStorage.setItem(TOKEN_KEY, token);
  } catch (error) {
    console.error('⚠️ Failed to set token:', error);
    throw error;
  }
}

export async function removeToken(): Promise<void> {
  try {
    await AsyncStorage.removeItem(TOKEN_KEY);
  } catch (error) {
    console.error('⚠️ Failed to remove token:', error);
    throw error;
  }
}

// Helper to create timeout promise
function createTimeoutPromise<T>(ms: number): Promise<T> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

// Validate response JSON
function validateJson(data: any): boolean {
  return data !== null && typeof data === 'object';
}

// Main request function with retry logic
async function request<T = any>(
  method: string,
  path: string,
  data?: any,
  isFormData = false,
  retries = MAX_RETRIES
): Promise<T> {
  if (!method || typeof method !== 'string') {
    throw new Error('Invalid HTTP method');
  }

  if (!path || typeof path !== 'string') {
    throw new Error('Invalid path');
  }

  let lastError: Error | null = null;
  let lastResponse: Response | null = null;

  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const token = await getToken();
      const headers: Record<string, string> = {
        'User-Agent': `Nexus-Mobile/${Platform.OS}`,
      };

      if (token && typeof token === 'string') {
        headers['Authorization'] = `Bearer ${token}`;
      }

      if (!isFormData && (!data || typeof data !== 'object' || data instanceof FormData === false)) {
        headers['Content-Type'] = 'application/json';
      }

      const url = `${getBaseUrl()}${path}`;
      if (!url || typeof url !== 'string') {
        throw new Error('Invalid request URL');
      }

      const body = isFormData ? data : data ? JSON.stringify(data) : undefined;

      const fetchPromise = fetch(url, {
        method,
        headers,
        body,
        timeout: REQUEST_TIMEOUT,
      });

      const response = await Promise.race([
        fetchPromise,
        createTimeoutPromise<Response>(REQUEST_TIMEOUT),
      ]);

      lastResponse = response;

      if (!response || typeof response !== 'object') {
        throw new Error('Invalid response');
      }

      // Parse response
      let json: any;
      try {
        const text = await response.text();
        if (text && typeof text === 'string') {
          json = JSON.parse(text);
        } else {
          json = { error: 'Empty response' };
        }
      } catch (parseError) {
        console.warn('⚠️ JSON parse error, using empty object');
        json = { error: 'Failed to parse response' };
      }

      if (!validateJson(json)) {
        json = { error: 'Invalid JSON response' };
      }

      // Check response status
      if (!response.ok) {
        const errorMsg = json.error || json.message || `Request failed: ${response.status}`;
        const statusError = new Error(errorMsg);
        (statusError as any).status = response.status;
        throw statusError;
      }

      return json as T;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      const status = (lastError as any).status;

      // Don't retry on client errors (4xx) except 408, 429, 500-599
      if (
        status &&
        status >= 400 &&
        status < 500 &&
        status !== 408 &&
        status !== 429
      ) {
        throw lastError;
      }

      // Check if we should retry
      if (attempt < retries - 1) {
        const delay = RETRY_DELAY_MS * Math.pow(2, attempt); // Exponential backoff
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  // All retries failed
  console.error('⚠️ Request failed after retries:', {
    method,
    path,
    lastError: lastError?.message,
    status: (lastResponse as any)?.status,
  });

  throw (
    lastError ||
    new Error('Request failed after retries')
  );
}

// API endpoints with full validation
export const api = {
  auth: {
    register: async (data: {
      username?: string;
      password: string;
      displayName: string;
    }) => {
      if (!data.password || !data.displayName) {
        throw new Error('Missing required fields');
      }
      return request('POST', '/api/auth/register', data);
    },
    login: async (data: { username?: string; password: string; email?: string }) => {
      if (!data.password || (!data.username && !data.email)) {
        throw new Error('Missing email/username and password');
      }
      return request('POST', '/api/auth/login', data);
    },
    me: () => request('GET', '/api/auth/me'),
  },
  users: {
    search: async (q: string) => {
      if (!q || typeof q !== 'string') {
        return [];
      }
      try {
        return await request('GET', `/api/users/search?q=${encodeURIComponent(q)}`);
      } catch (error) {
        console.error('⚠️ User search failed:', error);
        return [];
      }
    },
    get: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid user ID');
      }
      return request('GET', `/api/users/${id}`);
    },
    updateMe: async (data: {
      displayName?: string;
      bio?: string;
      age?: number;
      avatarUrl?: string;
    }) => {
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid user data');
      }
      return request('PUT', '/api/users/me', data);
    },
    updateStatus: async (data: { statusText: string; statusType: string }) => {
      if (!data.statusText || !data.statusType) {
        throw new Error('Missing status data');
      }
      return request('PUT', '/api/users/me/status', data);
    },
    block: async (userId: number) => {
      if (!userId || userId < 1) {
        throw new Error('Invalid user ID');
      }
      return request('POST', `/api/users/${userId}/block`);
    },
    unblock: async (userId: number) => {
      if (!userId || userId < 1) {
        throw new Error('Invalid user ID');
      }
      return request('DELETE', `/api/users/${userId}/block`);
    },
    addContact: async (userId: number) => {
      if (!userId || userId < 1) {
        throw new Error('Invalid user ID');
      }
      return request('POST', `/api/contacts/${userId}`);
    },
    contacts: () => request('GET', '/api/contacts'),
  },
  conversations: {
    list: async () => {
      try {
        return await request('GET', '/api/conversations');
      } catch (error) {
        console.error('⚠️ Failed to get conversations:', error);
        return [];
      }
    },
    create: async (data: {
      type: string;
      name?: string;
      description?: string;
      avatarUrl?: string;
      isPrivate?: boolean;
      memberIds?: number[];
      targetUserId?: number;
    }) => {
      if (!data || !data.type) {
        throw new Error('Missing conversation data');
      }
      return request('POST', '/api/conversations', data);
    },
    get: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      return request('GET', `/api/conversations/${id}`);
    },
    update: async (id: number, data: any) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid update data');
      }
      return request('PUT', `/api/conversations/${id}`, data);
    },
    delete: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      return request('DELETE', `/api/conversations/${id}`);
    },
    messages: async (id: number, before?: number, limit?: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      try {
        let path = `/api/conversations/${id}/messages`;
        const params = [];
        if (before && before > 0) params.push(`before=${before}`);
        if (limit && limit > 0) params.push(`limit=${limit}`);
        if (params.length > 0) path += `?${params.join('&')}`;
        return await request('GET', path);
      } catch (error) {
        console.error('⚠️ Failed to get messages:', error);
        return [];
      }
    },
    sendMessage: async (id: number, data: {
      content?: string;
      type: string;
      mediaUrl?: string;
      mediaSize?: number;
      mediaName?: string;
      mediaMime?: string;
      replyToId?: number;
    }) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      if (!data || !data.type) {
        throw new Error('Missing message data');
      }
      if (!data.content && !data.mediaUrl && data.type === 'text') {
        throw new Error('Message content is empty');
      }
      return request('POST', `/api/conversations/${id}/messages`, data);
    },
    editMessage: async (id: number, messageId: number, content: string) => {
      if (!id || id < 1 || !messageId || messageId < 1) {
        throw new Error('Invalid IDs');
      }
      if (!content || typeof content !== 'string') {
        throw new Error('Invalid content');
      }
      return request('PUT', `/api/conversations/${id}/messages/${messageId}`, { content });
    },
    deleteMessage: async (id: number, messageId: number) => {
      if (!id || id < 1 || !messageId || messageId < 1) {
        throw new Error('Invalid IDs');
      }
      return request('DELETE', `/api/conversations/${id}/messages/${messageId}`);
    },
    addReaction: async (id: number, messageId: number, emoji: string) => {
      if (!id || id < 1 || !messageId || messageId < 1) {
        throw new Error('Invalid IDs');
      }
      if (!emoji || typeof emoji !== 'string') {
        throw new Error('Invalid emoji');
      }
      return request('POST', `/api/conversations/${id}/messages/${messageId}/reactions`, {
        emoji,
      });
    },
    members: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid conversation ID');
      }
      try {
        return await request('GET', `/api/conversations/${id}/members`);
      } catch (error) {
        console.error('⚠️ Failed to get members:', error);
        return [];
      }
    },
    addMember: async (id: number, userId: number) => {
      if (!id || id < 1 || !userId || userId < 1) {
        throw new Error('Invalid IDs');
      }
      return request('POST', `/api/conversations/${id}/members`, { userId });
    },
    removeMember: async (id: number, userId: number) => {
      if (!id || id < 1 || !userId || userId < 1) {
        throw new Error('Invalid IDs');
      }
      return request('DELETE', `/api/conversations/${id}/members/${userId}`);
    },
  },
  channels: {
    search: async (q: string) => {
      if (!q || typeof q !== 'string') {
        return [];
      }
      try {
        return await request('GET', `/api/channels/search?q=${encodeURIComponent(q)}`);
      } catch (error) {
        console.error('⚠️ Channel search failed:', error);
        return [];
      }
    },
    subscribe: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid channel ID');
      }
      return request('POST', `/api/channels/${id}/subscribe`);
    },
    unsubscribe: async (id: number) => {
      if (!id || id < 1) {
        throw new Error('Invalid channel ID');
      }
      return request('DELETE', `/api/channels/${id}/subscribe`);
    },
  },
  feed: {
    videos: async (page = 0, type?: 'short' | 'long') => {
      try {
        if (page < 0) throw new Error('Invalid page');
        let path = `/api/feed/videos?page=${page}`;
        if (type && (type === 'short' || type === 'long')) {
          path += `&type=${type}`;
        }
        return await request('GET', path);
      } catch (error) {
        console.error('⚠️ Failed to get feed videos:', error);
        return [];
      }
    },
    myVideos: async () => {
      try {
        return await request('GET', '/api/feed/my-videos');
      } catch (error) {
        console.error('⚠️ Failed to get my videos:', error);
        return [];
      }
    },
    like: async (id: number) => {
      if (!id || id < 1) throw new Error('Invalid video ID');
      return request('POST', `/api/feed/videos/${id}/like`);
    },
    unlike: async (id: number) => {
      if (!id || id < 1) throw new Error('Invalid video ID');
      return request('DELETE', `/api/feed/videos/${id}/like`);
    },
    dislike: async (id: number) => {
      if (!id || id < 1) throw new Error('Invalid video ID');
      return request('POST', `/api/feed/videos/${id}/dislike`);
    },
    undislike: async (id: number) => {
      if (!id || id < 1) throw new Error('Invalid video ID');
      return request('DELETE', `/api/feed/videos/${id}/dislike`);
    },
    comments: async (videoId: number, page = 0) => {
      try {
        if (!videoId || videoId < 1 || page < 0) throw new Error('Invalid params');
        return await request('GET', `/api/feed/videos/${videoId}/comments?page=${page}`);
      } catch (error) {
        console.error('⚠️ Failed to get comments:', error);
        return [];
      }
    },
    postComment: async (videoId: number, content: string) => {
      if (!videoId || videoId < 1) throw new Error('Invalid video ID');
      if (!content || typeof content !== 'string') throw new Error('Invalid content');
      return request('POST', `/api/feed/videos/${videoId}/comments`, { content });
    },
    deleteComment: async (videoId: number, commentId: number) => {
      if (!videoId || videoId < 1 || !commentId || commentId < 1) throw new Error('Invalid IDs');
      return request('DELETE', `/api/feed/videos/${videoId}/comments/${commentId}`);
    },
    likeComment: async (videoId: number, commentId: number) => {
      if (!videoId || videoId < 1 || !commentId || commentId < 1) throw new Error('Invalid IDs');
      return request('POST', `/api/feed/videos/${videoId}/comments/${commentId}/like`);
    },
    dislikeComment: async (videoId: number, commentId: number) => {
      if (!videoId || videoId < 1 || !commentId || commentId < 1) throw new Error('Invalid IDs');
      return request('POST', `/api/feed/videos/${videoId}/comments/${commentId}/dislike`);
    },
    heartComment: async (videoId: number, commentId: number) => {
      if (!videoId || videoId < 1 || !commentId || commentId < 1) throw new Error('Invalid IDs');
      return request('POST', `/api/feed/videos/${videoId}/comments/${commentId}/heart`);
    },
    pinComment: async (videoId: number, commentId: number) => {
      if (!videoId || videoId < 1 || !commentId || commentId < 1) throw new Error('Invalid IDs');
      return request('POST', `/api/feed/videos/${videoId}/comments/${commentId}/pin`);
    },
    blockUser: async (userId: number) => {
      if (!userId || userId < 1) throw new Error('Invalid user ID');
      return request('POST', `/api/users/${userId}/block`);
    },
  },
  stories: {
    list: async () => {
      try {
        return await request('GET', '/api/stories');
      } catch (error) {
        console.error('⚠️ Failed to get stories:', error);
        return [];
      }
    },
    create: async (data: { contentUrl: string; contentType?: string; text?: string }) => {
      if (!data.contentUrl) throw new Error('Missing content URL');
      return request('POST', '/api/stories', data);
    },
  },
  notifications: {
    list: async () => {
      try {
        return await request('GET', '/api/notifications');
      } catch (error) {
        console.error('⚠️ Failed to get notifications:', error);
        return [];
      }
    },
    markRead: () => request('PUT', '/api/notifications/read'),
    registerToken: async (token: string, platform?: string) => {
      try {
        if (!token || typeof token !== 'string') throw new Error('Invalid token');
        return await request('POST', '/api/notifications/token', { token, platform });
      } catch (error) {
        console.warn('⚠️ Token registration failed, continuing');
        return null;
      }
    },
  },
  upload: {
    file: async (
      uri: string,
      type: string,
      name: string
    ): Promise<{ url: string; type: string; size: number; name: string }> => {
      try {
        if (!uri || typeof uri !== 'string') throw new Error('Invalid URI');
        if (!type || typeof type !== 'string') throw new Error('Invalid type');
        if (!name || typeof name !== 'string') throw new Error('Invalid filename');

        const token = await getToken();
        const formData = new FormData();
        (formData as any).append('file', {
          uri,
          type,
          name: name.substring(0, 255),
        });

        const response = await Promise.race([
          fetch(`${getBaseUrl()}/api/upload`, {
            method: 'POST',
            headers: {
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: formData,
          }),
          createTimeoutPromise<Response>(60000), // 60s for uploads
        ]);

        if (!response.ok) {
          const json = await response.json().catch(() => ({ error: 'Upload failed' }));
          throw new Error(json.error || `Upload failed: ${response.status}`);
        }

        const json = await response.json();
        if (!json.url || !json.type || !json.size || !json.name) {
          throw new Error('Invalid upload response');
        }

        return json;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : 'Upload failed';
        throw new Error(errorMsg);
      }
    },
  },
};
