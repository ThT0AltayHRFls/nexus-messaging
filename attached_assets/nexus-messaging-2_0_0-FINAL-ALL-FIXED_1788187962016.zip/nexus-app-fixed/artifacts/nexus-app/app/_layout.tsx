import React, { useEffect, useCallback } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack, router } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useAuth } from '@/context/AuthContext';
import { NotificationProvider } from '@/context/NotificationContext';
import { SocketProvider, useSocket } from '@/context/SocketContext';
import { CallProvider, useCall } from '@/context/CallContext';
import IncomingCallScreen from '@/components/IncomingCallScreen';

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
      gcTime: 300_000, // Cache time (formerly cacheTime)
    },
    mutations: {
      retry: 0,
    },
  },
});

function CallStateManager() {
  const { incomingCall, setIncomingCall, acceptCall, rejectCall, callError } = useCall();
  const { socket, isConnected } = useSocket();

  // Handle incoming call invites from socket
  useEffect(() => {
    if (!socket || !isConnected) return;

    const handleCallInvite = (data: any) => {
      try {
        // Validate incoming call data
        if (
          !data ||
          typeof data !== 'object' ||
          !data.callId ||
          !data.type ||
          !data.from ||
          !data.fromName ||
          !data.conversationId
        ) {
          console.error('⚠️ Invalid call invite data');
          return;
        }

        if (data.type !== 'voice' && data.type !== 'video') {
          console.error('⚠️ Invalid call type');
          return;
        }

        setIncomingCall({
          callId: data.callId,
          type: data.type,
          from: data.from,
          fromName: data.fromName,
          fromAvatar: data.fromAvatar || null,
          conversationId: data.conversationId,
          timestamp: Date.now(),
        });
      } catch (error) {
        console.error('⚠️ Failed to handle call invite:', error);
      }
    };

    const handleCallReject = (data: any) => {
      try {
        if (data?.callId && typeof data.callId === 'string') {
          rejectCall(data.callId);
        }
      } catch (error) {
        console.error('⚠️ Failed to handle call rejection:', error);
      }
    };

    const handleCallEnd = (data: any) => {
      try {
        if (data?.callId && typeof data.callId === 'string') {
          rejectCall(data.callId);
        }
      } catch (error) {
        console.error('⚠️ Failed to handle call end:', error);
      }
    };

    socket.on('call-invite', handleCallInvite);
    socket.on('call-rejected', handleCallReject);
    socket.on('call-ended', handleCallEnd);

    return () => {
      socket.off('call-invite', handleCallInvite);
      socket.off('call-rejected', handleCallReject);
      socket.off('call-ended', handleCallEnd);
    };
  }, [socket, isConnected, setIncomingCall, rejectCall]);

  // Safe accept handler
  const handleAcceptCall = useCallback(async () => {
    try {
      if (!incomingCall || !socket) {
        throw new Error('Invalid call state');
      }

      acceptCall(incomingCall);

      // Emit acceptance through socket
      socket.emit('call-accept', {
        callId: incomingCall.callId,
        conversationId: incomingCall.conversationId,
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Failed to accept call:', errorMsg);
    }
  }, [incomingCall, socket, acceptCall]);

  // Safe reject handler
  const handleRejectCall = useCallback(async () => {
    try {
      if (!incomingCall || !socket) {
        throw new Error('Invalid call state');
      }

      const callId = incomingCall.callId;
      rejectCall(callId);

      // Emit rejection through socket
      socket.emit('call-reject', { callId });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('⚠️ Failed to reject call:', errorMsg);
    }
  }, [incomingCall, socket, rejectCall]);

  return (
    <>
      <RootLayoutNav />
      {incomingCall && (
        <IncomingCallScreen
          callerId={incomingCall.from}
          callerName={incomingCall.fromName}
          callerAvatar={incomingCall.fromAvatar}
          callType={incomingCall.type}
          callId={incomingCall.callId}
          isVisible={!!incomingCall}
          onAccept={handleAcceptCall}
          onReject={handleRejectCall}
        />
      )}
      {callError && (
        <ErrorDisplay error={callError} />
      )}
    </>
  );
}

function ErrorDisplay({ error }: { error: Error }) {
  return null; // Silent error - logged already
}

function RootLayoutNav() {
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (isLoading) return;

    const navigateSafely = async () => {
      try {
        if (isAuthenticated) {
          await router.replace('/(tabs)');
        } else {
          await router.replace('/(auth)/login');
        }
      } catch (error) {
        console.error('⚠️ Navigation failed:', error);
        // Fallback - try again
        setTimeout(() => {
          navigateSafely();
        }, 1000);
      }
    };

    navigateSafely();
  }, [isAuthenticated, isLoading]);

  return (
    <Stack screenOptions={{ headerShown: false, animationEnabled: true }}>
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="conversation/[id]"
        options={{ headerShown: false, animation: 'slide_from_right' }}
      />
      <Stack.Screen
        name="user/[id]"
        options={{ headerShown: false, animation: 'slide_from_right' }}
      />
      <Stack.Screen
        name="search"
        options={{ headerShown: false, animation: 'slide_from_bottom' }}
      />
      <Stack.Screen
        name="create-group"
        options={{ headerShown: false, animation: 'slide_from_bottom' }}
      />
      <Stack.Screen
        name="create-channel"
        options={{ headerShown: false, animation: 'slide_from_bottom' }}
      />
      <Stack.Screen
        name="new-conversation"
        options={{ headerShown: false, animation: 'slide_from_bottom' }}
      />
      <Stack.Screen
        name="about"
        options={{ headerShown: false, animation: 'slide_from_right' }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    const setupApp = async () => {
      try {
        if (fontsLoaded || fontError) {
          await SplashScreen.hideAsync();
        }
      } catch (error) {
        console.error('⚠️ Failed to hide splash screen:', error);
      }
    };

    setupApp();
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AuthProvider>
                <SocketProvider>
                  <NotificationProvider>
                    <CallProvider>
                      <CallStateManager />
                    </CallProvider>
                  </NotificationProvider>
                </SocketProvider>
              </AuthProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}

// Import after other components to avoid circular dependency
import { AuthProvider } from '@/context/AuthContext';
