import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { Session, User as SupabaseUser } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase-premium';
import type { User } from '@/lib/types';

interface AuthContextValue {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  authError: Error | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// Validate and map user safely
function mapUser(authUser: SupabaseUser | null): User | null {
  try {
    if (!authUser) return null;

    const metadata = authUser.user_metadata ?? {};
    const email = authUser.email;

    if (!email) {
      throw new Error('User email not found');
    }

    const username = String(
      metadata.username ?? email.split('@')[0] ?? `nexus_${Date.now()}`
    ).substring(0, 30);

    const displayName = String(
      metadata.display_name ?? metadata.username ?? email ?? 'Nexus User'
    ).substring(0, 50);

    const user: User = {
      id: (metadata.user_id ?? parseInt(authUser.id, 10)) as unknown as number,
      username,
      displayName,
      bio: metadata.bio ? String(metadata.bio).substring(0, 500) : null,
      avatarUrl: metadata.avatar_url ? String(metadata.avatar_url) : null,
      createdAt: authUser.created_at || new Date().toISOString(),
    };

    // Validate required fields
    if (!user.id || !user.username || !user.displayName) {
      throw new Error('Invalid user data');
    }

    return user;
  } catch (error) {
    console.error('⚠️ mapUser failed:', error);
    return null;
  }
}

// Validate email
function validateEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate password
function validatePassword(password: string): boolean {
  if (!password || typeof password !== 'string') return false;
  return password.length >= 8;
}

// Validate display name
function validateDisplayName(displayName: string): boolean {
  if (!displayName || typeof displayName !== 'string') return false;
  return displayName.trim().length >= 2 && displayName.trim().length <= 50;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<Error | null>(null);
  const isMountedRef = React.useRef(true);

  const applySession = useCallback((session: Session | null) => {
    try {
      if (!isMountedRef.current) return;

      if (!session) {
        setToken(null);
        setUser(null);
        setAuthError(null);
        return;
      }

      if (!session.access_token) {
        throw new Error('No access token in session');
      }

      const mappedUser = mapUser(session.user);
      if (!mappedUser) {
        throw new Error('Failed to map user data');
      }

      setToken(session.access_token);
      setUser(mappedUser);
      setAuthError(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Session mapping failed');
      console.error('⚠️ applySession failed:', err.message);
      setAuthError(err);
      setToken(null);
      setUser(null);
    }
  }, []);

  // Initialize auth state
  useEffect(() => {
    isMountedRef.current = true;

    const initAuth = async () => {
      try {
        setIsLoading(true);
        setAuthError(null);

        const { data, error } = await supabase.auth.getSession();

        if (!isMountedRef.current) return;

        if (error) {
          console.error('⚠️ getSession failed:', error.message);
          setAuthError(error);
          applySession(null);
        } else {
          applySession(data.session);
        }
      } catch (error) {
        const err = error instanceof Error ? error : new Error('Auth initialization failed');
        console.error('⚠️ Auth initialization failed:', err.message);
        if (isMountedRef.current) {
          setAuthError(err);
          applySession(null);
        }
      } finally {
        if (isMountedRef.current) {
          setIsLoading(false);
        }
      }
    };

    initAuth();

    // Subscribe to auth state changes
    let subscription: any = null;
    try {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        if (isMountedRef.current) {
          applySession(session);
        }
      });
      subscription = data;
    } catch (error) {
      console.error('⚠️ Auth listener setup failed:', error);
    }

    return () => {
      isMountedRef.current = false;
      try {
        if (subscription?.unsubscribe) {
          subscription.unsubscribe();
        }
      } catch (error) {
        console.error('⚠️ Auth listener cleanup failed:', error);
      }
    };
  }, [applySession]);

  const login = useCallback(
    async (email: string, password: string) => {
      try {
        // Validate inputs
        const trimmedEmail = email.trim();
        if (!validateEmail(trimmedEmail)) {
          throw new Error('Geçersiz e-posta adresi');
        }

        if (!validatePassword(password)) {
          throw new Error('Şifre en az 8 karakter olmalıdır');
        }

        if (!isMountedRef.current) return;

        const { data, error } = await supabase.auth.signInWithPassword({
          email: trimmedEmail,
          password,
        });

        if (!isMountedRef.current) return;

        if (error) {
          console.error('⚠️ Login failed:', error.message);
          throw error;
        }

        if (!data.session) {
          throw new Error('Oturum açılamadı. Lütfen e-posta adresinizi doğrulayın ve tekrar deneyin.');
        }

        const mappedUser = mapUser(data.user);
        if (!mappedUser) {
          throw new Error('Kullanıcı verisi alınamadı');
        }

        applySession(data.session);
      } catch (error) {
        const err = error instanceof Error ? error : new Error('Giriş başarısız');
        if (isMountedRef.current) {
          setAuthError(err);
          throw err;
        }
      }
    },
    [applySession]
  );

  const register = useCallback(
    async (email: string, password: string, displayName: string) => {
      try {
        // Validate inputs
        const trimmedEmail = email.trim();
        const trimmedName = displayName.trim();

        if (!validateEmail(trimmedEmail)) {
          throw new Error('Geçersiz e-posta adresi');
        }

        if (!validatePassword(password)) {
          throw new Error('Şifre en az 8 karakter olmalıdır');
        }

        if (!validateDisplayName(trimmedName)) {
          throw new Error('Ad 2-50 karakter arasında olmalıdır');
        }

        if (!isMountedRef.current) return;

        const { data, error } = await supabase.auth.signUp({
          email: trimmedEmail,
          password,
          options: {
            data: {
              display_name: trimmedName,
              username: trimmedEmail.split('@')[0],
            },
            emailRedirectTo: undefined,
          },
        });

        if (!isMountedRef.current) return;

        if (error) {
          console.error('⚠️ Registration failed:', error.message);
          throw error;
        }

        if (!data.user) {
          throw new Error('Kullanıcı oluşturulamadı');
        }

        // If auto-confirmed
        if (data.session) {
          applySession(data.session);
        } else {
          // If email verification required
          throw new Error('Kayıt başarılı! Lütfen e-posta adresinizi doğrulayın.');
        }
      } catch (error) {
        const err = error instanceof Error ? error : new Error('Kayıt başarısız');
        if (isMountedRef.current) {
          setAuthError(err);
          throw err;
        }
      }
    },
    [applySession]
  );

  const logout = useCallback(async () => {
    try {
      if (!isMountedRef.current) return;

      const { error } = await supabase.auth.signOut();

      if (!isMountedRef.current) return;

      if (error) {
        console.error('⚠️ Logout failed:', error.message);
        throw error;
      }

      applySession(null);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Çıkış başarısız');
      if (isMountedRef.current) {
        setAuthError(err);
        throw err;
      }
    }
  }, [applySession]);

  const updateUser = useCallback((data: Partial<User>) => {
    try {
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid user data');
      }

      if (isMountedRef.current) {
        setUser((previous) => {
          if (!previous) return null;
          return { ...previous, ...data };
        });
      }
    } catch (error) {
      console.error('⚠️ updateUser failed:', error);
    }
  }, []);

  const clearError = useCallback(() => {
    if (isMountedRef.current) {
      setAuthError(null);
    }
  }, []);

  const value: AuthContextValue = {
    user,
    token,
    isLoading,
    isAuthenticated: !!user && !!token,
    authError,
    login,
    register,
    logout,
    updateUser,
    clearError,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth() must be used within <AuthProvider>');
  }
  return context;
}
