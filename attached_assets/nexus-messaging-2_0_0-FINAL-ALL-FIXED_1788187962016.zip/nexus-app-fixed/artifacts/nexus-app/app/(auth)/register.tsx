import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { register } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const isMountedRef = useRef(true);

  React.useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const validateEmail = useCallback((email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }, []);

  const handleRegister = useCallback(async () => {
    try {
      const emailVal = String(email || '').trim();
      const passwordVal = String(password || '').trim();
      const confirmVal = String(confirmPassword || '').trim();
      const nameVal = String(displayName || '').trim();

      // Validation
      if (!emailVal) {
        Alert.alert('Hata', 'E-posta adresini girin');
        return;
      }

      if (!validateEmail(emailVal)) {
        Alert.alert('Hata', 'Geçerli bir e-posta adresi girin');
        return;
      }

      if (!passwordVal) {
        Alert.alert('Hata', 'Şifreyi girin');
        return;
      }

      if (passwordVal.length < 8) {
        Alert.alert('Hata', 'Şifre en az 8 karakter olmalıdır');
        return;
      }

      if (passwordVal !== confirmVal) {
        Alert.alert('Hata', 'Şifreler eşleşmiyor');
        return;
      }

      if (!nameVal) {
        Alert.alert('Hata', 'Adını girin');
        return;
      }

      if (nameVal.length < 2 || nameVal.length > 50) {
        Alert.alert('Hata', 'Ad 2-50 karakter arasında olmalıdır');
        return;
      }

      if (!isMountedRef.current) return;
      setIsLoading(true);

      await register(emailVal, passwordVal, nameVal);

      if (!isMountedRef.current) return;

      try {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (e) {
        console.warn('Haptic failed:', e);
      }

      try {
        router.replace('/(tabs)' as any);
      } catch (navError) {
        console.error('Navigation failed:', navError);
        if (isMountedRef.current) {
          Alert.alert('Hata', 'Sayfaya gidilemedi.');
        }
      }
    } catch (err: any) {
      if (!isMountedRef.current) return;

      try {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } catch (e) {
        console.warn('Haptic failed:', e);
      }

      const errorMsg = err?.message || 'Kayıt başarısız oldu';
      Alert.alert('Kayıt Hatası', errorMsg);
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [email, password, confirmPassword, displayName, register, validateEmail]);

  const handleLoginPress = useCallback(() => {
    try {
      router.push('/(auth)/login' as any);
    } catch (error) {
      console.error('Navigation error:', error);
    }
  }, []);

  const bgColor = colors?.background || '#0B0B14';
  const secondary = colors?.secondary || '#1a1a2e';
  const foreground = colors?.foreground || '#FFFFFF';
  const muted = colors?.mutedForeground || '#999999';
  const primary = colors?.primary || '#7C3AED';
  const accent = colors?.accent || '#EC4899';

  return (
    <LinearGradient
      colors={[bgColor, secondary, bgColor]}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={[
            styles.container,
            {
              paddingTop: (insets?.top || 0) + 40,
              paddingBottom: (insets?.bottom || 0) + 40,
            },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text style={[styles.title, { color: foreground }]}>Kaydol</Text>
            <Text style={[styles.subtitle, { color: muted }]}>
              Hesap oluşturarak başlayın
            </Text>
          </View>

          {/* Form */}
          <View style={styles.formContainer}>
            {/* Display Name */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>Ad Soyad</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="person" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="Adınız Soyadınız"
                  placeholderTextColor={muted}
                  value={displayName}
                  onChangeText={(text) => setDisplayName(String(text || ''))}
                  editable={!isLoading}
                  maxLength={50}
                />
              </View>
            </View>

            {/* Email */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>E-Posta</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="mail" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="example@example.com"
                  placeholderTextColor={muted}
                  value={email}
                  onChangeText={(text) => setEmail(String(text || ''))}
                  editable={!isLoading}
                  keyboardType="email-address"
                  maxLength={100}
                />
              </View>
            </View>

            {/* Password */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>Şifre</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="lock-closed" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="En az 8 karakter"
                  placeholderTextColor={muted}
                  value={password}
                  onChangeText={(text) => setPassword(String(text || ''))}
                  secureTextEntry={!showPassword}
                  editable={!isLoading}
                  maxLength={100}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  <Ionicons
                    name={showPassword ? 'eye' : 'eye-off'}
                    size={18}
                    color={primary}
                  />
                </TouchableOpacity>
              </View>
            </View>

            {/* Confirm Password */}
            <View style={styles.inputWrapper}>
              <Text style={[styles.label, { color: foreground }]}>Şifreyi Onayla</Text>
              <View
                style={[
                  styles.inputContainer,
                  { borderColor: primary },
                  { backgroundColor: secondary },
                ]}
              >
                <Ionicons name="lock-closed" size={18} color={primary} />
                <TextInput
                  style={[styles.input, { color: foreground }]}
                  placeholder="Şifrenizi tekrar girin"
                  placeholderTextColor={muted}
                  value={confirmPassword}
                  onChangeText={(text) => setConfirmPassword(String(text || ''))}
                  secureTextEntry={!showConfirm}
                  editable={!isLoading}
                  maxLength={100}
                />
                <TouchableOpacity
                  onPress={() => setShowConfirm(!showConfirm)}
                  disabled={isLoading}
                >
                  <Ionicons
                    name={showConfirm ? 'eye' : 'eye-off'}
                    size={18}
                    color={primary}
                  />
                </TouchableOpacity>
              </View>
            </View>

            {/* Register Button */}
            <TouchableOpacity
              style={[styles.button, { backgroundColor: primary }]}
              onPress={handleRegister}
              disabled={isLoading}
              activeOpacity={0.8}
            >
              {isLoading ? (
                <ActivityIndicator color="#FFF" />
              ) : (
                <Text style={styles.buttonText}>Kaydol</Text>
              )}
            </TouchableOpacity>

            {/* Login Link */}
            <View style={styles.loginContainer}>
              <Text style={[styles.loginText, { color: muted }]}>
                Zaten hesabın var mı?{' '}
              </Text>
              <TouchableOpacity
                onPress={handleLoginPress}
                disabled={isLoading}
              >
                <Text style={[styles.loginLink, { color: primary }]}>
                  Giriş Yap
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  container: {
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    fontWeight: '500',
  },
  formContainer: {
    gap: 20,
  },
  inputWrapper: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 50,
    gap: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  button: {
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  loginText: {
    fontSize: 14,
  },
  loginLink: {
    fontSize: 14,
    fontWeight: '600',
  },
});
